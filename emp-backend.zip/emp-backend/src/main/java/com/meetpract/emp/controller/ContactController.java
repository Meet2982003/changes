package com.meetpract.emp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.meetpract.emp.entity.ContactEntity;
import com.meetpract.emp.repository.ContactRepository;

import java.util.Optional;

@RestController
@RequestMapping("/contacts")
public class ContactController {

    @Autowired
    private ContactRepository contactRepo;

    // First Method: Overwrites the entire entity, including null values
    @PutMapping("/updateFirst/{id}")
    public ResponseEntity<ContactEntity> updateContactFirst(@RequestBody ContactEntity contact, @PathVariable Long id) {
      
        // Fetch existing contact
        ContactEntity existingContact = contactRepo.findById(id).orElseThrow(() ->
                new RuntimeException("Contact not found with id: " + id));

        // Save the provided contact (replaces all fields, even with nulls)
        contact.setContactId(id); // Ensure the ID remains consistent
        ContactEntity updatedContact = contactRepo.save(contact);

        return ResponseEntity.ok(updatedContact);
    }

    // Second Method: Updates only specific fields explicitly
    @PutMapping("/updateSecond/{id}")
    public ResponseEntity<ContactEntity> updateContactSecond(@RequestBody ContactEntity contact, @PathVariable Long id) {
        // Fetch existing contact
        ContactEntity existingContact = contactRepo.findById(id).orElseThrow(() ->
                new RuntimeException("Contact not found with id: " + id));

        // Update only non-null fields
        if (contact.getContactName() != null) {
            existingContact.setContactName(contact.getContactName());
        }
        if (contact.getDesignation() != null) {
            existingContact.setDesignation(contact.getDesignation());
        }
        if (contact.getIpPhone() != null) {
            existingContact.setIpPhone(contact.getIpPhone());
        }

        ContactEntity updatedContact = contactRepo.save(existingContact);

        return ResponseEntity.ok(updatedContact);
    }

    // Example endpoint to create a new contact for testing
    @PostMapping("/create")
    public ResponseEntity<ContactEntity> createContact(@RequestBody ContactEntity contact) {
        ContactEntity savedContact = contactRepo.save(contact);
        return ResponseEntity.ok(savedContact);
    }

    // Example endpoint to fetch a contact for testing
    @GetMapping("/{id}")
    public ResponseEntity<ContactEntity> getContact(@PathVariable Long id) {
        ContactEntity contact = contactRepo.findById(id).orElseThrow(() ->
                new RuntimeException("Contact not found with id: " + id));
        return ResponseEntity.ok(contact);
    }
}

