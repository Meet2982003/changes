package com.meetpract.emp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.meetpract.emp.entity.ContactEntity;

// Repository interface
@Repository
public interface ContactRepository extends JpaRepository<ContactEntity, Long> {
}

